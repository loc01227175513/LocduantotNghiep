import React from "react";

import Homedashboardstudent from "./home/page"

export default function Dashboardstudent(){
    return (
     
            <Homedashboardstudent />
   
    
    )
}