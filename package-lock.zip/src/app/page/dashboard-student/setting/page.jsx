"use client";
import React from 'react'
import Page from './setting/page'
export default function page() {
    
  return (
    <>
     <Page/>
    </>
  )
}
