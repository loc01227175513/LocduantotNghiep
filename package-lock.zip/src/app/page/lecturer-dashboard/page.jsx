import React from "react";

import Homedashboardlecturer from "./home/page"

export default function Dashboardlecturer(){
    return (
       
        <Homedashboardlecturer/>
    )
}